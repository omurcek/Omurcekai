import difflib
import random
import json
import requests
import re
import math
from collections import Counter, deque
from flask import Flask, request

app = Flask(__name__)


def tokenize(text):
    text = text.lower()
    text = re.sub(r"https?://\S+", " ", text)
    text = re.sub(r"[^a-z0-9ığüşöçİĞÜŞÖÇ\s\-']", " ", text, flags=re.IGNORECASE)
    tokens = [t for t in text.split() if len(t) > 0]
    return tokens

def simple_stem(token):
    for suf in ["ler", "lar", "ını", "ini", "un", "ün", "imiz", "ımız", "leri", "ları", "dir", "dır", "muş", "miş", "acak", "ecek", "iyor"]:
        if token.endswith(suf) and len(token) - len(suf) >= 3:
            return token[:-len(suf)]
    return token

def normalize_tokens(tokens):
    return [simple_stem(t) for t in tokens]

def tf_vector(tokens):
    return Counter(tokens)

def cosine_sim(c1, c2):
    # c1, c2: Counter
    if not c1 or not c2:
        return 0.0
    dot = 0.0
    for k, v in c1.items():
        dot += v * c2.get(k, 0)
    norm1 = math.sqrt(sum(v*v for v in c1.values()))
    norm2 = math.sqrt(sum(v*v for v in c2.values()))
    if norm1 == 0 or norm2 == 0:
        return 0.0
    return dot / (norm1 * norm2)

def ngram(tokens, n=2):
    return list(zip(*[tokens[i:] for i in range(n)]))

class AppRouter:
    def __init__(self, data_file="users.json"):
        self.app = Flask(__name__)
        self.data_file = data_file
        self.routes()

    def read_data(self):
        if not os.path.exists(self.data_file):
            return []
        with open(self.data_file, "r", encoding="utf-8") as f:
            return json.load(f)

    def write_data(self, data):
        with open(self.data_file, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def serve_file(self, filename):
        try:
            with open(filename, "r", encoding="utf-8") as f:
                return f.read(), 200, {"Content-Type": "text/html"}
        except Exception as e:
            return f"<h1>Dosya bulunamadı</h1><p>{str(e)}</p>", 404

    def routes(self):
        @self.app.route("/chatbot/map")
        def serve_map():
            return self.serve_file("map.html")  # Katkı haritası ana sayfa

        @self.app.route("/users.json", methods=["GET"])
        def get_users():
            data = self.read_data()
            return json.dumps(data, ensure_ascii=False), 200, {"Content-Type": "application/json"}

        @self.app.route("/add", methods=["POST"])
        def add_user():
            try:
                payload = request.get_json()
                if not payload or "country" not in payload:
                    return {"error": "Eksik veri"}, 400

                country = payload["country"]
                lat = payload.get("latitude")
                lon = payload.get("longitude")

                data = self.read_data()
                for entry in data:
                    if entry["country"].lower() == country.lower():
                        entry["users"] += 1
                        self.write_data(data)
                        return {"status": "Güncellendi", "country": country}, 200

                if lat is None or lon is None:
                    return {"error": "Yeni ülke için koordinatlar gerekli"}, 400

                new_entry = {
                    "country": country,
                    "latitude": lat,
                    "longitude": lon,
                    "users": 1,
                    "platform": ["Web"],
                    "language": ["Bilinmiyor"],
                    "added_at": datetime.datetime.utcnow().isoformat()
                }
                data.append(new_entry)
                self.write_data(data)
                return {"status": "Yeni ülke eklendi", "country": country}, 200

            except Exception as e:
                return {"error": str(e)}, 500

    def run(self):
        self.app.run()

# Başlat
if __name__ == "__main__":
    server = AppRouter()
    server.run()

class OmurcekAI:
    def __init__(self):
        self.data = []
        self.words = []
        self.conversation_history = []

    def save(self, file):
        try:
            with open(file, "w", encoding="utf-8") as f:
                json.dump({"data": self.data, "words": self.words}, f, ensure_ascii=False, indent=4)
        except Exception as e:
            print(f"Error saving: {e}")

    def load(self, file):
        try:
            with open(file, "r", encoding="utf-8") as f:
                data = json.load(f)
                self.data = data.get("data", [])
                self.words = data.get("words", [])
        except:
            self.data, self.words = [], []

    def train(self, text):
        if text not in self.data:
            self.data.append(text)
        for h in text.lower().strip().split():
            if h not in self.words and h not in ["a", "an", "the", "is", "am", "are", "was", "were", "be", "to", "of", "and", "in", "on", "at", "for", "with", "it", "its", "i", "you", "he", "she", "we", "they", "me", "him", "her", "us", "them"]:
                self.words.append(h)

    def meaning(self, text):
        new = []
        for h in text.lower().strip().split():
            if h in self.words:
                new.append(h)
            else:
                best_match, max_sim = None, 0.0
                for word in self.words:
                    val = difflib.SequenceMatcher(None, word, h).ratio()
                    if val > max_sim:
                        max_sim, best_match = val, word
                if max_sim > 0.6:
                    new.append(best_match)
                else:
                    new.append(h)
        return " ".join(new)

    def same_think(self, prompt, text):
        cp = [h for h in prompt.lower().split() if h not in "_&-+()/@#₺:;~!?.,"]
        ct = [h for h in text.lower().split() if h not in "!?., \n"]
        if not cp or not ct:
            return 0.0
        overlap = len(set(cp) & set(ct)) / len(set(cp)) if cp else 0.0
        pb = set((cp[i], cp[i+1]) for i in range(len(cp)-1))
        tb = set((ct[i], ct[i+1]) for i in range(len(ct)-1))
        bigram = len(pb & tb)/len(pb) if pb else 0.0
        return overlap*0.7 + bigram*0.3

    def fetch_external_data(self, url):
        try:
            r = requests.get(url, timeout=4)
            if r.status_code == 200:
                return r.text[:500] + ("..." if len(r.text) > 500 else "")
            return f"Failed: {r.status_code}"
        except Exception as e:
            return f"Error: {e}"

    def talk(self, prompt, trainbot=True, temperature=0.2):
        if not prompt.strip():
            return ""
        if prompt.lower().startswith("fetch "):
            url = prompt[6:].strip()
            if not (url.startswith("http://") or url.startswith("https://")):
                return "Please provide a valid URL starting with http:// or https://."
            return self.fetch_external_data(url)

        mp = self.meaning(prompt)
        scored, best = [], ("I don't get it.", 0.1)
        for text in self.data:
            val = self.same_think(mp, text)
            if val > best[1]:
                best = (text, val)
            if val >= (1 - temperature):
                scored.append((text, val))
        scored.sort(key=lambda x: x[1], reverse=True)
        if scored:
            nc = max(1, int(len(scored) * (temperature+0.1)))
            chosen = random.choice(scored[:nc])[0]
        else:
            chosen = best[0]

        if trainbot:
            self.train(prompt)
        self.conversation_history.append({"prompt": prompt, "response": chosen})
        self.conversation_history = self.conversation_history[-5:]
        return chosen

from difflib import SequenceMatcher

class LehnLM:
	def __init__(self):
		self.texts = []
		self.lentexts = 0
		self.words = []
	def add(self, text):
		self.texts.append(text)
		self.lentexts += len(text)
		for h in text.split():
			if h not in self.words:
				self.words.append(h)
	def remove(self, text):
		if text in self.texts:
			self.texts.remove(text)
			words = []
			lentexts = 0
			for h in self.texts:
				lentexts += len(h)
				for h2 in h.split():
					if h2 not in words:
						words.append(h2)
			self.words = words
			self.lentexts = lentexts
	def remove_has(self, text):
		for h in list(self.texts):
			if text in h:
				self.texts.remove(h)
		words = []
		lentexts = 0
		for h in self.texts:
			lentexts += len(h)
			for h2 in h.split():
				if h2 not in words:
					words.append(h2)
		self.words = words
		self.lentexts = lentexts
	def replace_inner(self, text, text2):
		for h in list(self.texts):
			if text in h:
				self.texts.remove(h)
				h = h.replace(text, text2)
				self.texts.append(h)
		words = []
		lentexts = 0
		for h in self.texts:
			lentexts += len(h)
			for h2 in h.split():
				if h2 not in words:
					words.append(h2)
		self.words = words
		self.lentexts = lentexts
	def process(self, p, maxlength=32, responses=1, requiremaxlength=True, spaces=None, optimization_spaces=True):
		response_mosts = {}
		lenp = len(p)
		if spaces == None:
			spaces = max(int((lenp+maxlength)/2), 1)
		if optimization_spaces:
			spaces += min(int(self.lentexts/1024), spaces)
		for text in self.texts:
			mosts = {}
			ns = []
			lentext = len(text)
			spacerange = []
			for n in range(lentext):
				if n%spaces == 0 or n == 0:
					spacerange.append(n)
			for n in spacerange:
				n = max(n-lenp, 0)
				if n not in ns:
					ns.append(n)
					t = text[n:n+lenp]
					s = SequenceMatcher(None, t, p).ratio()
					st = text[n+lenp:n+lenp+maxlength]
					while s in mosts:
						s += 0.000000000000001

					mosts[s] = st
			if len(mosts) > 0:
				for v, h in mosts.items():
					if requiremaxlength:
						v += (len(h)/maxlength)/2
					while v in response_mosts:
						v += 0.000000000000001
					response_mosts[v] = h
		response_mosts = dict(sorted(response_mosts.items(), key=lambda item: item[0], reverse=True))
		return [h for v, h in response_mosts.items()][:responses]
	def restore(self, text, replacewords=True, minseq=0.3):
		new = []
		for h in text.split():
			if h not in self.words:
				if replacewords:
					most = ""
					mostv = 0
					for h2 in self.words:
						v = SequenceMatcher(None, h, h2).ratio()
						if v >= mostv and v >= minseq:
							mostv = v
							most = h2
					if most != "":
						new.append(most)
			else:
				new.append(h)
		return " ".join(new)

class OmurcekAI_LehnLM:
    def __init__(self):
        global chatbot
        self.engine = LehnLM()
        self.maxlength = 0
        for data in chatbot.data:
            self.engine.add(data);lendata = len(data)
            if lendata >= self.maxlength:
                self.maxlength = lendata
    def update(self):
        global chatbot
        self.engine = LehnLM()
        self.maxlength = 0
        for data in chatbot.data:
            self.engine.add(data);lendata = len(data)
            if lendata >= self.maxlength:
                self.maxlength = lendata
    def talk(self, text, temperature=0):
        prompt = text
        if prompt.lower().startswith("fetch "):
            url = prompt[6:].strip()
            if not (url.startswith("http://") or url.startswith("https://")):
                return "Please provide a valid URL starting with http:// or https://."
            return chatbot.fetch_external_data(url)
        return self.engine.restore(random.choice(self.engine.process(text, maxlength=(len(text)*2)+20, spaces=16, responses=int((temperature/2)*70)+1, requiremaxlength=True)).strip())

chatbot = OmurcekAI()
chatbot.load("CHATBOT_DATA.json")
chatbot_lehnlm = OmurcekAI_LehnLM()

@app.route("/chatbot")
def chatbot_page():
    return """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>OmurcekAI - ChatBot</title>
  <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-RD06WE730X"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-RD06WE730X');
</script>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
  <style>
    html, body {height:100%; margin:0; padding:0;}
    body {font-family:'Roboto',sans-serif;background:#000;color:#FFD700;display:flex;justify-content:center;align-items:center;}

    .container{width:100%;height:100%;max-width:1920px;max-height:1080px;display:flex;flex-direction:column;justify-content:flex-start;align-items:center;border-radius:12px;box-shadow:0 0 30px rgba(255,215,0,.08);background:linear-gradient(180deg,#050505 0%, #0b0b0b 100%);padding:28px;box-sizing:border-box;}

    .header-row{width:100%;display:flex;flex-direction:column;align-items:center;gap:6px;margin-bottom:6px}
    h1{margin:6px 0 0;color:#FFD700;text-shadow:0 0 10px rgba(255,215,0,.15);font-size:28px}

    .warning{max-width:980px;width:94%;text-align:center;font-size:0.92rem;color:#ffb3b3;background:rgba(255,85,85,0.03);padding:8px 12px;border-radius:8px;border:1px solid rgba(255,85,85,0.08);box-shadow:inset 0 1px 0 rgba(255,85,85,0.02);}
    .description{margin-top:6px;text-align:center;font-size:.92rem;padding:6px;color:#FFD700;opacity:.95}

    .messages{flex-grow:1;width:100%;background:#0d0d0d;border:1px solid rgba(255,215,0,0.06);overflow-y:auto;padding:12px;margin:18px 0;border-radius:10px;box-shadow:inset 0 0 20px rgba(255,215,0,.02);min-height:220px}
    .message-user{text-align:right;background:linear-gradient(135deg,#FFD700,#FFB700);color:#000;padding:8px 12px;margin:8px 0;border-radius:15px 15px 0 15px;max-width:70%;margin-left:auto;word-wrap:break-word;box-shadow:0 0 12px rgba(255,215,0,.15);}
    .message-bot{text-align:left;background:rgba(255,215,0,.06);color:#FFD700;padding:8px 12px;margin:8px 0;border-radius:15px 15px 15px 0;max-width:70%;margin-right:auto;word-wrap:break-word;box-shadow:0 0 8px rgba(255,215,0,.08);}

    .input-container{display:flex;justify-content:space-between;width:100%;gap:12px;margin-bottom:8px}
    .input-field{flex-grow:1;padding:12px;border:1px solid rgba(255,215,0,.12);border-radius:8px;background:transparent;color:#FFD700;transition:box-shadow .25s, background .25s;font-size:15px}
    .input-field:focus{outline:none;box-shadow:0 0 28px rgba(255,215,0,.18);background:#0b0b0b}
    .input-field.typing{box-shadow:0 0 28px rgba(255,215,0,.28);}

    .send-button{width:110px;padding:10px 12px;background:#FFD700;border:none;border-radius:8px;cursor:pointer;color:#000;font-weight:700;transition:transform .14s,box-shadow .18s;font-size:15px}
    .send-button:hover{transform:translateY(-2px);box-shadow:0 6px 30px rgba(255,215,0,.18)}
    .send-button:active{animation:glowPulse .9s ease}

    .settings{width:100%;margin-top:12px;border-top:1px dashed rgba(255,215,0,.06);padding-top:14px;display:flex;flex-direction:column;align-items:center;gap:10px}
    .settings-header{color:#FFD700;font-weight:600;margin-bottom:0}
    .train-row{display:flex;align-items:center;gap:12px;justify-content:center;flex-wrap:wrap}
    .train-row .train-label{color:#FFD700;font-size:15px;margin:0}

    .toggle-switch{position:relative;display:inline-block;width:60px;height:34px}
    .toggle-switch input{opacity:0;width:0;height:0}
    .slider{position:absolute;cursor:pointer;top:0;left:0;right:0;bottom:0;background:#222;border:1px solid rgba(255,215,0,.12);transition:.35s;border-radius:34px}
    .slider:before{position:absolute;content:"";height:26px;width:26px;left:4px;bottom:3px;background:#FFD700;transition:.35s;border-radius:50%;box-shadow:0 6px 18px rgba(255,215,0,.10)}
    .toggle-switch input:checked + .slider{background:#FFD700;box-shadow:0 0 28px rgba(255,215,0,.16)}
    .toggle-switch input:checked + .slider:before{transform:translateX(26px);background:#000;box-shadow:0 10px 30px rgba(255,215,0,.18);animation:glowPulse 1.4s infinite alternate}

    .temp-row{display:flex;align-items:center;gap:12px;justify-content:center}
    select{appearance:none;-webkit-appearance:none;-moz-appearance:none;padding:10px 14px;border-radius:999px;border:1px solid rgba(255,215,0,.12);background:linear-gradient(180deg,#0b0b0b,#0d0d0d);color:#FFD700;cursor:pointer;font-weight:600}
    .select-wrap{position:relative}
    .select-wrap:after{content:"▾";position:absolute;right:12px;top:9px;color:#FFD700;pointer-events:none}
    select:hover{box-shadow:0 8px 26px rgba(255,215,0,.06)}
    select:focus{outline:none;box-shadow:0 0 30px rgba(255,215,0,.12)}

    /* Butonlar */
    .manifest-row{margin-top:10px;}
    .manifest-button{padding:10px 18px;border:none;border-radius:8px;background:linear-gradient(135deg,#FFD700,#FFB700);color:#000;font-weight:700;cursor:pointer;transition:transform 0.15s,box-shadow 0.2s;box-shadow:0 0 18px rgba(255,215,0,0.08);}
    .manifest-button:hover{transform:translateY(-2px);box-shadow:0 6px 28px rgba(255,215,0,0.18);}
    .manifest-button:active{transform:translateY(0);box-shadow:0 0 14px rgba(255,215,0,0.25);}

    .buttons-row {display:flex;justify-content:center;align-items:center;gap:12px;margin-top:10px;}

    .usermap-button {background:linear-gradient(135deg,#00aaff,#0077ff);color:#fff;box-shadow:0 0 18px rgba(0,136,255,0.25);}
    .usermap-button:hover{transform:translateY(-2px);box-shadow:0 6px 28px rgba(0,136,255,0.45);}
    .usermap-button:active{transform:translateY(0);box-shadow:0 0 14px rgba(0,136,255,0.5);}

    @keyframes glowPulse{from{box-shadow:0 0 8px rgba(255,215,0,.12)}to{box-shadow:0 0 28px rgba(255,215,0,.28)}}

    .modal-overlay{position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.7);z-index:1200}
    .modal{width:min(720px,92%);background:linear-gradient(180deg,#060606,#0b0b0b);border:1px solid rgba(255,215,0,.12);padding:22px;border-radius:12px;text-align:center;color:#FFD700;box-shadow:0 10px 50px rgba(0,0,0,.6)}
    .modal h3{margin:0 0 8px;color:#fff}
    .modal p{color:#ffd6d6;margin:0 0 14px}
    .modal .btn{display:inline-block;padding:10px 16px;border-radius:10px;background:#FFD700;color:#000;border:none;cursor:pointer;font-weight:700;box-shadow:0 8px 30px rgba(255,215,0,.12)}
    .modal .controls{margin-top:8px;display:flex;gap:12px;align-items:center;justify-content:center}
    .modal label{color:#ffd6d6;font-size:14px}
  </style>
</head>
<body>
  <div class="container">
    <div class="header-row">
      <h1>OmurcekAI - ChatBot ⚡</h1>
      <div class="warning">⚠ This is an AI — we can't control what it learns or says. Responsibility is not ours.</div>
      <div class="description">Train, chat & vibe with this AI. Use <b>fetch [URL]</b>!</div>
    </div>

    <div id="messages" class="messages"></div>

    <div class="input-container">
      <input type="text" id="userInput" placeholder="Type your message..." class="input-field" autocomplete="off">
      <button id="sendButton" class="send-button">Send</button>
    </div>

    <div class="settings">
      <div class="settings-header">⚙ Chat Settings</div>

      <div class="train-row">
        <div class="train-label">Train the bot with my messages:</div>
        <label class="toggle-switch"><input type="checkbox" id="trainToggle" checked><span class="slider"></span></label>
        <div class="train-label">LehnLM (New Model):</div>
        <label class="toggle-switch"><input type="checkbox" id="lehnlmToggle"><span class="slider"></span></label>
      </div>

      <div class="temp-row">
        <div class="select-wrap"><select id="temperatureSelect"><option value="0.0">0.0 (Precise)</option><option value="0.15">0.15 (Smart)</option><option value="0.4" selected>0.4 (Default)</option><option value="0.7">0.7 (Creative)</option><option value="1.0">1.0 (Wild)</option></select></div>
      </div>

      <div class="manifest-row buttons-row">
        <button id="manifestBtn" class="manifest-button">Manifest</button>
        <button id="userMapBtn" class="manifest-button usermap-button">User Map</button>
      </div>
    </div>
  </div>

  <div id="modalOverlay" class="modal-overlay">
    <div class="modal">
      <h3>Important — Read before using</h3>
      <p>This is an AI. We cannot control what it learns or says. We are not responsible for outputs generated by this bot.</p>
      <div class="controls">
        <label><input type="checkbox" id="dontShow"> Don't show again</label>
      </div>
      <div style="margin-top:14px"><button id="understandBtn" class="btn">I understand</button></div>
    </div>
  </div>

  <script>
    const modal = document.getElementById('modalOverlay');
    const dontShow = localStorage.getItem('hideAiWarning');
    if (!dontShow) {
      modal.style.display = 'flex';
    }
    document.getElementById('understandBtn').addEventListener('click', ()=>{
      if(document.getElementById('dontShow').checked){
        localStorage.setItem('hideAiWarning', '1');
      }
      modal.style.display='none';
    });

    document.getElementById('sendButton').addEventListener('click', function(){
      const userInput = document.getElementById('userInput');
      const message = userInput.value;
      if (message.trim() === '') return;
      const messagesDiv = document.getElementById('messages');
      messagesDiv.innerHTML += `<div class="message-user">${message}</div>`;
      messagesDiv.scrollTop = messagesDiv.scrollHeight;
      userInput.value = '';

      const train = document.getElementById('trainToggle').checked;
      const lehnlm = document.getElementById('lehnlmToggle').checked;
      const temperature = document.getElementById('temperatureSelect').value;

      fetch('/chatbot/api/free/use', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: message, train: train, lehnlm: lehnlm, temperature: parseFloat(temperature) })
      })
      .then(r => r.text())
      .then(d => {
        messagesDiv.innerHTML += `<div class="message-bot">${d}</div>`;
        messagesDiv.scrollTop = messagesDiv.scrollHeight;
      })
      .catch(e => {
        messagesDiv.innerHTML += `<div class="message-bot" style="color:red;">Error: ${e.message}</div>`;
        messagesDiv.scrollTop = messagesDiv.scrollHeight;
      });

      const btn = document.getElementById('sendButton');
      btn.classList.add('active');
      setTimeout(()=>btn.classList.remove('active'), 800);
    });

    let typingTimer;
    const input = document.getElementById('userInput');
    input.addEventListener('input', ()=>{
      input.classList.add('typing');
      clearTimeout(typingTimer);
      typingTimer = setTimeout(()=>{ input.classList.remove('typing'); }, 800);
    });

    input.addEventListener('keydown', (e)=>{
      if(e.key === 'Enter'){
        e.preventDefault();
        document.getElementById('sendButton').click();
      }
    });

    document.getElementById('manifestBtn').addEventListener('click', () => {
      window.location.href = '/chatbot/manifest';
    });

    document.getElementById('userMapBtn').addEventListener('click', () => {
      window.location.href = '/chatbot/map';
    });
  </script>
</body>
</html>
"""
@app.route("/chatbot/api/free/use", methods=["POST"])
def chatbot_free_use():
    global chatbot, chatbot_lehnlm
    try:
        data = request.get_json()
        text_input = data.get("text", "")
        train_bot_flag = data.get("train", True)
        temp_value = data.get("temperature", 0.4)
        model = data.get("lehnlm", False)
        if model:
            result = chatbot_lehnlm.talk(text_input, temperature=temp_value)
            if train_bot_flag:
                chatbot.train(text_input)
        else:
            result = chatbot.talk(text_input, trainbot=bool(train_bot_flag), temperature=float(temp_value))
        if train_bot_flag:
            chatbot.save("CHATBOT_DATA.json")
            chatbot_lehnlm.update()
        return "Sorry. I dont know." if len(result)==0 else result
    except Exception as e:
        print(f"API Error: {e}")
        return "Internal error. Try again later."

if __name__ == "__main__":
    app.run(debug=True)