import difflib
import random
import json
import requests
from flask import Flask, request

app = Flask(__name__)

class OmurcekAI:
    def __init__(self):
        self.data = []  # Stores raw sentences/phrases the bot has learned
        self.words = [] # Stores unique words encountered
        self.conversation_history = [] # To store recent interactions for context

    def save(self, file):
        """Saves the chatbot's data (learned sentences and words) to a JSON file."""
        try:
            with open(file, "w", encoding="utf-8") as f:
                # Use indent for pretty-printing JSON, ensure_ascii=False for non-ASCII characters
                json.dump({"data": self.data, "words": self.words}, f, ensure_ascii=False, indent=4)
        except IOError as e:
            print(f"Error saving data to {file}: {e}")
        except Exception as e:
            print(f"An unexpected error occurred during save: {e}")

    def load(self, file):
        """Loads the chatbot's data from a JSON file."""
        try:
            with open(file, "r", encoding="utf-8") as f:
                data = json.load(f)
                self.data = data.get("data", []) # Use .get() with default to prevent KeyError
                self.words = data.get("words", [])
            print(f"Successfully loaded {len(self.data)} data entries and {len(self.words)} unique words from {file}.")
        except FileNotFoundError:
            print(f"Memory file '{file}' not found. Starting with empty memory.")
            self.data = []
            self.words = []
        except json.JSONDecodeError as e:
            print(f"Error decoding JSON from {file}: {e}. Starting with empty memory.")
            self.data = []
            self.words = []
        except Exception as e:
            print(f"An unexpected error occurred during load: {e}. Starting with empty memory.")
            self.data = []
            self.words = []

    def train(self, text):
        """Adds new text to the chatbot's memory and updates its vocabulary."""
        if text not in self.data: # Avoid adding duplicate sentences
            self.data.append(text)
        
        # Add unique words from the text to the vocabulary
        for h in text.lower().strip().split():
            # Simple stop word removal for better vocabulary quality
            if h not in self.words and h not in ["a", "an", "the", "is", "am", "are", "was", "were", "be", "to", "of", "and", "in", "on", "at", "for", "with", "it", "its", "i", "you", "he", "she", "we", "they", "me", "him", "her", "us", "them"]:
                self.words.append(h)

    def meaning(self, text):
        """
        Processes input text to find known words or highly similar words.
        This helps in normalizing the input for better matching.
        """
        new = []
        processed_text_words = text.lower().strip().split()

        for h in processed_text_words:
            if h in self.words:
                new.append(h)
            else:
                # Attempt to find a semantically similar word if direct match fails
                best_match = None
                max_similarity = 0.0

                for word in self.words:
                    value = difflib.SequenceMatcher(None, word, h).ratio()
                    if value > max_similarity:
                        max_similarity = value
                        best_match = word
                
                # Only use the "best_match" if it's above a certain threshold (e.g., 60% similarity)
                # Otherwise, use a placeholder or the original word if no good match
                if max_similarity > 0.6: # Adjustable threshold for "close enough" words
                    new.append(best_match)
                else:
                    new.append(h) # Keep the original word if no good match found
        return " ".join(new)

    def same_think(self, prompt, text):
        """
        Calculates a similarity score between a prompt and a stored text.
        This version considers both word overlap and basic word order (bigrams).
        """
        # Clean prompt and text by removing punctuation and converting to lowercase
        clean_prompt_words = [h for h in prompt.lower().split() if h not in "_&-+()/@#₺:;~!?.,"]
        clean_text_words = [h for h in text.lower().split() if h not in "!?., \n"]

        if not clean_prompt_words or not clean_text_words:
            return 0.0

        # 1. Basic word overlap ratio
        common_words = set(clean_prompt_words) & set(clean_text_words)
        overlap_ratio = len(common_words) / len(set(clean_prompt_words)) if clean_prompt_words else 0.0

        # 2. Bigram (two-word sequence) overlap ratio for basic word order
        prompt_bigrams = set()
        for i in range(len(clean_prompt_words) - 1):
            prompt_bigrams.add((clean_prompt_words[i], clean_prompt_words[i+1]))

        text_bigrams = set()
        for i in range(len(clean_text_words) - 1):
            text_bigrams.add((clean_text_words[i], clean_text_words[i+1]))

        bigram_overlap_ratio = 0.0
        if prompt_bigrams:
            common_bigrams = prompt_bigrams & text_bigrams
            bigram_overlap_ratio = len(common_bigrams) / len(prompt_bigrams)

        # Combine ratios with weights (these weights can be tuned for desired behavior)
        # Word overlap is generally more important, but bigrams add context.
        combined_score = (overlap_ratio * 0.7) + (bigram_overlap_ratio * 0.3)
        
        return combined_score

    def fetch_external_data(self, url):
        """Fetches data from a given URL, with a timeout and character limit."""
        try:
            response = requests.get(url, timeout=5)
            if response.status_code == 200:
                # Return first 500 characters to avoid huge responses
                return response.text[:500] + ("..." if len(response.text) > 500 else "")
            else:
                return f"Failed to fetch data from {url}: HTTP {response.status_code}"
        except requests.exceptions.Timeout:
            return f"Error fetching data from {url}: Request timed out after 5 seconds."
        except requests.exceptions.RequestException as e:
            return f"Error fetching data from {url}: {str(e)}"
        except Exception as e:
            return f"An unexpected error occurred while fetching data from {url}: {str(e)}"

    def talk(self, prompt, trainbot=True, temperature=0.2):
        """
        Generates a response to a given prompt.
        - `trainbot`: If True, the bot learns from the prompt.
        - `temperature`: Controls the randomness of the response selection (0.0 = deterministic, 1.0 = highly random).
        """
        if not prompt.strip():
            return ""

        # Handle 'fetch' command for external data
        if prompt.lower().startswith("fetch "):
            url = prompt[6:].strip()
            if not (url.startswith("http://") or url.startswith("https://")):
                return "Please provide a valid URL starting with http:// or https://."
            return self.fetch_external_data(url)

        # Process the prompt to get its "meaning" using the enhanced method
        meaning_of_prompt = self.meaning(prompt)

        scored_responses = []
        # Default "I don't understand" message, more helpful than just "sorry"
        default_unclear_response = ("I'm having a bit of trouble understanding that. Could you try rephrasing it or giving me more context?", 0.1)
        best_single_match = default_unclear_response

        # Evaluate all stored data against the prompt
        for text in self.data:
            value = self.same_think(meaning_of_prompt, text)
            
            if value > best_single_match[1]:
                best_single_match = (text, value)
            
            # Collect responses that are above a certain relevance threshold (influenced by temperature)
            # A lower (1-temperature) means we need a higher match to consider it.
            if value >= (1 - temperature): 
                scored_responses.append((text, value))
        
        # Sort responses by score in descending order
        scored_responses.sort(key=lambda x: x[1], reverse=True)

        chosen_response = ""
        if len(scored_responses) > 0:
            # Select a response from the top candidates based on temperature
            # Higher temperature allows more deviation from the absolute best match
            num_candidates = max(1, int(len(scored_responses) * (temperature + 0.1))) # Ensure at least 1 candidate
            if num_candidates > len(scored_responses):
                num_candidates = len(scored_responses)

            # Pick a random response from the top 'num_candidates'
            chosen_response = random.choice(scored_responses[:num_candidates])[0]
        else:
            # If no good matches, use the best single match found (which might be the default unclear response)
            chosen_response = best_single_match[0]

        # Format the prompt for training (capitalization, punctuation)
        newprompt = ""
        upperlevel = True
        for h in prompt:
            if upperlevel:
                if h in ".,!? 1234567890_()+-/₺#@":
                    newprompt += h
                else:
                    newprompt += h.upper()
                    upperlevel = False
            else:
                if h in ".!?\"\'":
                    upperlevel = True
                    newprompt += h
                else:
                    newprompt += h.lower()
        if not (newprompt.endswith(".") or newprompt.endswith(",") or newprompt.endswith("!") or newprompt.endswith("?")):
            newprompt += "."
        
        # Train the bot with the formatted prompt if enabled
        if trainbot:
            self.train(newprompt)
            # Optionally, train with the chosen response as well to create conversational pairs
            # self.train(chosen_response) 

        # Update conversation history (keep last 5 interactions)
        self.conversation_history.append({"prompt": prompt, "response": chosen_response})
        self.conversation_history = self.conversation_history[-5:]

        return chosen_response

# Initialize chatbot and load data
chatbot = OmurcekAI()
chatbot.load("CHATBOT_DATA.json")

@app.route("/chatbot")
def chatbot_page():
    return """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OmurcekAI - ChatBot</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #121212; /* Dark background */
            color: #FFD700; /* Gold color for text */
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: auto;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
            overflow: hidden;
            background: linear-gradient(180deg, rgba(18, 18, 18, 0.9), rgba(0, 0, 0, 0.8));
        }

        h1 {
            text-align: center;
            margin-bottom: 10px;
            border-bottom: 2px solid #FFD700;
            padding-bottom: 10px;
        }

        .description {
            text-align: center;
            font-size: 0.9em;
            margin-bottom: 20px;
            padding: 10px;
        }

        .messages {
            background-color: rgba(30, 30, 30, 0.9);
            color: #FFD700;
            border: 1px solid #FFD700;
            height: 300px;
            overflow-y: auto;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.5);
        }

        .message-user {
            text-align: right;
            background-color: #FFD700;
            color: black;
            padding: 8px 12px;
            margin: 5px 0;
            border-radius: 15px 15px 0 15px;
            max-width: 70%;
            margin-left: auto;
            word-wrap: break-word;
        }

        .message-bot {
            text-align: left;
            background-color: #333; /* Darker background for bot messages */
            color: #FFD700;
            padding: 8px 12px;
            margin: 5px 0;
            border-radius: 15px 15px 15px 0;
            max-width: 70%;
            margin-right: auto;
            word-wrap: break-word;
        }

        .input-container {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .input-field {
            flex-grow: 1; /* Allow input field to take available space */
            padding: 10px;
            border: 1px solid #FFD700;
            border-radius: 5px;
            background-color: #1E1E1E;
            color: #FFD700;
            transition: border-color 0.3s;
            margin-right: 10px; /* Space between input and button */
        }

        .input-field:focus {
            border-color: #FF8C00; /* Lighter orange */
            outline: none;
            box-shadow: 0 0 5px rgba(255, 140, 0, 0.8);
        }

        .send-button {
            width: 100px; /* Fixed width for send button */
            padding: 10px;
            background-color: #FFD700;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            color: black;
            transition: background-color 0.3s, transform 0.2s;
        }

        .send-button:hover {
            background-color: #FF8C00; /* Lighter orange */
            transform: scale(1.05);
        }

        .settings {
            text-align: center;
            margin-top: 20px;
            border-top: 2px solid #FFD700;
            padding-top: 10px;
        }

        .settings-header {
            margin-bottom: 20px;
        }

        .settings-label {
            display: block;
            margin: 10px 0 5px;
            font-size: 1em;
        }

        .radio-group {
            margin: 10px 0;
            display: flex;
            justify-content: center;
        }

        .radio-group label {
            margin-right: 20px;
            color: #FFD700;
        }
        select {
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #FFD700;
            background-color: #1E1E1E;
            color: #FFD700;
            cursor: pointer;
        }
        select:focus {
            border-color: #FF8C00;
            outline: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>OmurcekAI - ChatBot</h1>
        <p class="description">This AI has basic training data in Turkish and English, and users can train it based on their requests. Use 'fetch [URL]' to get data from a website!</p>

        <div id="messages" class="messages"></div>

        <div class="input-container">
            <input type="text" id="userInput" placeholder="Type your message..." class="input-field" onkeydown="if(event.keyCode === 13) document.getElementById('sendButton').click()">
            <button id="sendButton" class="send-button">Send</button>
        </div>

        <div class="settings">
            <h2 class="settings-header">- - - + Chat Settings + - - -</h2>
            <label class="settings-label">Train the bot with my messages:</label>
            <div class="radio-group">
                <label><input type="radio" name="train" value="true" checked> True</label>
                <label><input type="radio" name="train" value="false"> False</label>
            </div>
            <label class="settings-label">Bot temperature (0.0 = precise, 1.0 = creative/random):</label>
            <select id="temperatureSelect">
                <option value="0.0">0.0 (Most Precise)</option>
                <option value="0.1">0.1</option>
                <option value="0.2">0.2</option>
                <option value="0.3">0.3</option>
                <option value="0.4" selected>0.4 (Default)</option>
                <option value="0.5">0.5</option>
                <option value="0.6">0.6</option>
                <option value="0.7">0.7</option>
                <option value="0.8">0.8</option>
                <option value="0.9">0.9</option>
                <option value="1.0">1.0 (Most Creative)</option>
            </select>
        </div>
    </div>

    <script>
        document.getElementById('sendButton').addEventListener('click', function() {
            const userInput = document.getElementById('userInput');
            const message = userInput.value;

            if (message.trim() === "") return; // Don't send empty messages

            const messagesDiv = document.getElementById('messages');
            messagesDiv.innerHTML += `<div class="message-user">${message}</div>`; // Use new class

            userInput.value = ''; // Clear input immediately

            const train = document.querySelector('input[name="train"]:checked').value;
            const temperature = document.getElementById('temperatureSelect').value;

            fetch('/chatbot/api/free/use', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    text: message,
                    train: train === "true",
                    temperature: parseFloat(temperature)
                }),
            })
            .then(response => response.text())
            .then(data => {
                messagesDiv.innerHTML += `<div class="message-bot">${data}</div>`; // Use new class
                messagesDiv.scrollTop = messagesDiv.scrollHeight; // Scroll to the bottom
            })
            .catch(error => {
                console.error('Error:', error);
                messagesDiv.innerHTML += `<div class="message-bot" style="color: red;">Error communicating with bot: ${error.message}</div>`;
                messagesDiv.scrollTop = messagesDiv.scrollHeight;
            });
        });
    </script>
</body>
</html>"""

@app.route("/chatbot/api/free/use", methods=["POST"])
def chatbot_free_use():
    global chatbot
    try:
        data = request.get_json()
        # Ensure all expected keys are present with default values if not provided
        text_input = data.get("text", "")
        train_bot_flag = data.get("train", True)
        temp_value = data.get("temperature", 0.4) # Default temperature

        result = chatbot.talk(text_input, trainbot=bool(train_bot_flag), temperature=float(temp_value))
        
        # Save data only if training is enabled and a change might have occurred
        if train_bot_flag:
            chatbot.save("CHATBOT_DATA.json")
            
        return result
    except Exception as e:
        print(f"API Error: {e}")
        # Provide a more user-friendly error message
        return "I encountered an internal error and cannot respond right now. Please try again later."

if __name__ == "__main__":
    app.run(debug=True)
