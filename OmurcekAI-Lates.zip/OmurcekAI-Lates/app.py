import os
import json
import re
import webbrowser
from flask import Flask, request, render_template_string, jsonify
from difflib import SequenceMatcher
from collections import Counter

app = Flask(__name__)

# --- LEHNLM PRO LOCAL ENGINE ---
class LehnLM_Local:
    def __init__(self, storage_file="chatbot_data.json"):
        self.storage_file = storage_file
        self.texts = []
        self.word_map = {}
        self.load_from_json()

    def clean(self, text):
        return re.sub(r'[^\w\s]', '', str(text)).lower().strip()

    def add(self, text):
        if not text or text in self.texts: return
        self.texts.append(text)
        idx = len(self.texts) - 1
        
        # Kelime indeksleme (Hız için)
        words = self.clean(text).split()
        for w in words:
            if w not in self.word_map: self.word_map[w] = set()
            self.word_map[w].add(idx)
        
        self.save_to_json()

    def load_from_json(self):
        if os.path.exists(self.storage_file):
            try:
                with open(self.storage_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    # Sadece "responses" anahtarı altındaki listeyi al
                    for t in data.get("responses", []):
                        self.add(t)
                print(f">>> {len(self.texts)} veri basariyla yüklendi.")
            except Exception as e:
                print(f">>> Yükleme hatasi: {e}")

    def save_to_json(self):
        try:
            with open(self.storage_file, "w", encoding="utf-8") as f:
                json.dump({"responses": self.texts}, f, ensure_ascii=False, indent=4)
        except Exception as e:
            print(f">>> Kaydetme hatasi: {e}")

    def process(self, query):
        cleaned_query = self.clean(query)
        query_words = cleaned_query.split()
        if not query_words: return []

        # Hızlı eleme (Aday belirleme)
        candidate_indices = []
        for w in query_words:
            if w in self.word_map:
                candidate_indices.extend(list(self.word_map[w]))

        if not candidate_indices:
            candidates = self.texts[-50:] # Hiç yoksa son 50
        else:
            counts = Counter(candidate_indices).most_common(50)
            candidates = [self.texts[i] for i, count in counts]

        scored_results = []
        for text in candidates:
            cleaned_text = self.clean(text)
            # Hibrit Skor: Karakter benzerliği + Kelime eşleşme bonusu
            base_ratio = SequenceMatcher(None, cleaned_query, cleaned_text).ratio()
            match_count = sum(1 for w in query_words if w in cleaned_text)
            
            final_score = base_ratio + (match_count / len(query_words)) * 0.5
            if cleaned_query in cleaned_text: final_score += 0.3
            
            scored_results.append((final_score, text))

        scored_results.sort(key=lambda x: x[0], reverse=True)
        return [scored_results[0][1]] if scored_results and scored_results[0][0] > 0.45 else []

engine = LehnLM_Local()

# --- FALLOUT TERMINAL INTERFACE ---
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>ROBCO INDUSTRIES LOCAL TERMINAL</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=VT323&display=swap');
        
        :root {
            --amber: #ffb100;
            --amber-dim: #6e4d00;
            --bg: #0a0a05;
        }

        body, html {
            margin: 0; padding: 0; height: 100%;
            background: var(--bg); color: var(--amber);
            font-family: 'VT323', monospace; overflow: hidden;
        }

        .crt-container {
            width: 100vw; height: 100vh;
            display: flex; flex-direction: column;
            padding: 40px; box-sizing: border-box;
            position: relative;
        }

        /* Scanlines & CRT Kavisi */
        .crt-container::before {
            content: " "; position: absolute; top: 0; left: 0; width: 100%; height: 100%;
            background: linear-gradient(rgba(18, 16, 16, 0) 50%, rgba(0, 0, 0, 0.15) 50%);
            z-index: 10; background-size: 100% 4px; pointer-events: none;
        }

        #log {
            flex: 1; overflow-y: auto;
            text-shadow: 0 0 10px var(--amber);
            font-size: 1.8rem; scrollbar-width: none;
        }
        #log::-webkit-scrollbar { display: none; }

        .line { margin-bottom: 8px; animation: flicker 0.1s infinite; }
        .user { color: #fff; text-shadow: 0 0 15px #fff; }
        .bot { color: var(--amber); }

        .input-row {
            display: flex; border-top: 2px solid var(--amber-dim);
            padding-top: 20px; margin-top: 10px; z-index: 20;
        }

        input {
            background: transparent; border: none; color: var(--amber);
            font-family: 'VT323', monospace; font-size: 2rem;
            flex: 1; outline: none; text-transform: uppercase;
        }

        @keyframes flicker {
            0% { opacity: 0.99; } 50% { opacity: 1; } 100% { opacity: 0.98; }
        }
    </style>
</head>
<body>
    <div class="crt-container">
        <div id="log">
            <div class="line">ROBCO INDUSTRIES (TM) TERMLINK PROTOCOL</div>
            <div class="line">DATA_SOURCE: CHATBOT_DATA.JSON</div>
            <div class="line">------------------------------------------</div>
            <div class="line bot">WELCOME, OVERSEER. STANDBY FOR INPUT...</div>
        </div>
        <div class="input-row">
            <span style="font-size: 2rem; margin-right: 10px;">></span>
            <input type="text" id="userInput" autofocus autocomplete="off">
        </div>
    </div>

    <script>
        const log = document.getElementById('log');
        const input = document.getElementById('userInput');

        async function send() {
            const val = input.value.trim();
            if(!val) return;

            log.innerHTML += `<div class="line user">> ${val.toUpperCase()}</div>`;
            input.value = '';
            log.scrollTop = log.scrollHeight;

            try {
                const res = await fetch('/api', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({text: val})
                });
                const data = await res.json();
                
                const botDiv = document.createElement('div');
                botDiv.className = 'line bot';
                botDiv.innerHTML = "REPLY: ";
                log.appendChild(botDiv);

                let i = 0;
                const msg = data.reply.toUpperCase();
                function type() {
                    if (i < msg.length) {
                        botDiv.innerHTML += msg.charAt(i);
                        i++; log.scrollTop = log.scrollHeight;
                        setTimeout(type, 15);
                    }
                }
                type();
            } catch(e) { log.innerHTML += `<div class="line" style="color:red">!! ERROR: CONNECTION INTERRUPTED !!</div>`; }
        }
        input.onkeypress = (e) => { if(e.key === 'Enter') send(); };
        document.body.onclick = () => input.focus();
    </script>
</body>
</html>
"""

@app.route("/")
def home():
    return render_template_string(HTML_TEMPLATE)

@app.route("/api", methods=["POST"])
def api():
    msg = request.json.get("text", "").strip()
    if not msg: return jsonify({"reply": "NO_INPUT"})
    
    # İşle ve Cevap Bul
    res = engine.process(msg)
    reply = res[0] if res else "COMMAND_UNKNOWN. DATA_STORED_IN_JSON."
    
    # Öğrenme: Her şeyi ekle ve JSON'a yaz
    engine.add(msg)
    
    return jsonify({"reply": reply})

if __name__ == "__main__":
    # Tarayıcıyı otomatik aç
    webbrowser.open("http://127.0.0.1:5000")
    app.run(port=5000, debug=False)