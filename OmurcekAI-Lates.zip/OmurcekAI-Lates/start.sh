#!/bin/bash

# Create virtual environment
python3 -m venv venv

# Activate virtual environment
source venv/bin/activate

# Upgrade pip
python -m pip install --upgrade pip

# Install required packages
pip install flask requests

# Set environment variables for Flask
export FLASK_APP=app.py
export FLASK_ENV=development

# Run Flask app
flask run
