//
//  LEANInstallation.h
//  GoNativeIOS
//
//  Created by Weiyin He on 8/9/14.
//  Copyright (c) 2014 GoNative.io LLC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LEANInstallation : NSObject

+ (NSDictionary*)info;

@end
