import difflib
import random
import json
import requests
import re
import math
from collections import Counter, deque
from flask import Flask, request

app = Flask(__name__)


def tokenize(text):
    text = text.lower()
    text = re.sub(r"https?://\S+", " ", text)
    text = re.sub(r"[^a-z0-9ığüşöçİĞÜŞÖÇ\s\-']", " ", text, flags=re.IGNORECASE)
    tokens = [t for t in text.split() if len(t) > 0]
    return tokens

def simple_stem(token):
    for suf in ["ler", "lar", "ını", "ini", "un", "ün", "imiz", "ımız", "leri", "ları", "dir", "dır", "muş", "miş", "acak", "ecek", "iyor"]:
        if token.endswith(suf) and len(token) - len(suf) >= 3:
            return token[:-len(suf)]
    return token

def normalize_tokens(tokens):
    return [simple_stem(t) for t in tokens]

def tf_vector(tokens):
    return Counter(tokens)

def cosine_sim(c1, c2):
    # c1, c2: Counter
    if not c1 or not c2:
        return 0.0
    dot = 0.0
    for k, v in c1.items():
        dot += v * c2.get(k, 0)
    norm1 = math.sqrt(sum(v*v for v in c1.values()))
    norm2 = math.sqrt(sum(v*v for v in c2.values()))
    if norm1 == 0 or norm2 == 0:
        return 0.0
    return dot / (norm1 * norm2)

def ngram(tokens, n=2):
    return list(zip(*[tokens[i:] for i in range(n)]))

class OmurcekAI:
    def __init__(self):
        # Orijinal JSON uyumluluğu için `data` (düz metin listesi) ve `words` (kelime listesi) tutcam
        self.data = []    # ham cevap/girdi örnekleri (orijinal format koruncak)
        self.words = []   # sözlük (orijinal format korunaak)
        # Ek veri yapıları (anlık, saklasın diye dosyaya yazma zorunlu değil)
        self._vectors = {}   # text -> Counter (tf) ön-önbellek simon evet bunları ben yazdım ki aç karınla kod yazarken neyin ne olduğunu anlim bazen resmi yazdım.
        self._bigrams = {}   # text -> set(bigram tuples)
        self.conversation_history = deque(maxlen=20)  # daha uzun bağlam tutuyz (en son 20)
        # stop-words benzeri kısa liste (çok genel kelimeleri words'e eklemiyoruz)
        self._stop = set(["ve", "bir", "bu", "o", "için", "ile", "da", "de", "mi", "mu", "mı", "veya", "ama", "ki"])

    def save(self, file):
        try:
            # Yalnızca orijinal iki alanı saklıyoruz, böylece diğer sistemlerle uyum bozulmaz
            with open(file, "w", encoding="utf-8") as f:
                json.dump({"data": self.data, "words": self.words}, f, ensure_ascii=False, indent=4)
        except Exception as e:
            print(f"Error saving: {e}")

    def load(self, file):
        try:
            with open(file, "r", encoding="utf-8") as f:
                data = json.load(f)
                self.data = data.get("data", [])
                self.words = data.get("words", [])
        except Exception:
            self.data, self.words = [], []
        # önbellekleri yeniden oluştur
        self._reindex_all()

    def _index_text(self, text):
        toks = normalize_tokens(tokenize(text))
        vec = tf_vector([t for t in toks if t and t not in self._stop])
        self._vectors[text] = vec
        self._bigrams[text] = set(ngram(toks, 2))
        return vec

    def _reindex_all(self):
        self._vectors.clear()
        self._bigrams.clear()
        for t in self.data:
            self._index_text(t)

    def train(self, text):
        # Gelen özgün metni veri setine ekle (duplikat kontrolü)
        if text not in self.data:
            self.data.append(text)
            self._index_text(text)
        # kelime dağarcığını genişlet
        toks = normalize_tokens(tokenize(text))
        for h in toks:
            if h and h not in self.words and h not in self._stop:
                self.words.append(h)

    def meaning(self, text):
        # Tokenleri normalleştir; bilinmeyenleri en yakın bilinenle eşleştir
        toks = normalize_tokens(tokenize(text))
        mapped = []
        for t in toks:
            if t in self.words or t in self._stop:
                mapped.append(t)
            else:
                # En iyi eşleşeni difflib ile bul (eşik daha sıkı)
                best_match, max_sim = None, 0.0
                for w in self.words:
                    sim = difflib.SequenceMatcher(None, w, t).ratio()
                    if sim > max_sim:
                        max_sim, best_match = sim, w
                if max_sim > 0.65:
                    mapped.append(best_match)
                else:
                    mapped.append(t)
        return " ".join(mapped)

    def same_think(self, prompt, text):
        """
        Çok bileşenli benzerlik:
         - TF-kosinüs benzerliği (ağırlık: 0.6)
         - bigram örtüşmesi (0.25)
         - konuşma bağlamı (recency boost) (0.15)
        Dönen değer [0..1]
        """
        # prompt ve text ön-işleme
        p_toks = normalize_tokens(tokenize(prompt))
        p_vec = tf_vector([t for t in p_toks if t and t not in self._stop])

        t_vec = self._vectors.get(text) or self._index_text(text)
        vec_sim = cosine_sim(p_vec, t_vec)

        p_bi = set(ngram(p_toks, 2))
        t_bi = self._bigrams.get(text, set())
        bi_sim = (len(p_bi & t_bi) / len(p_bi)) if p_bi else 0.0

        # recency: eğer text conversation_history içinde yakınsa küçük bonus ver
        recency_score = 0.0
        for idx, entry in enumerate(reversed(self.conversation_history)):
            # entry: {"prompt":..., "response":...}
            if entry.get("response") == text:
                # son cevaplara daha fazla ağırlık (0.2 -> 0.02 arası)
                recency_score = max(recency_score, 0.2 * (1 - (idx / len(self.conversation_history))))
                break

        score = vec_sim * 0.6 + bi_sim * 0.25 + recency_score * 0.15
        # normalize (garanti)
        return max(0.0, min(1.0, score))

    def fetch_external_data(self, url):
        try:
            r = requests.get(url, timeout=5)
            if r.status_code == 200:
                return r.text[:1000] + ("..." if len(r.text) > 1000 else "")
            return f"Failed: {r.status_code}"
        except Exception as e:
            return f"Error: {e}"

    def talk(self, prompt, trainbot=True, temperature=0.2):
        # Boş istek
        if not prompt or not prompt.strip():
            return ""

        # Özel komut: fetch URL
        if prompt.lower().startswith("fetch "):
            url = prompt[6:].strip()
            if not (url.startswith("http://") or url.startswith("https://")):
                return "Please provide a valid URL starting with http:// or https://."
            return self.fetch_external_data(url)

        # Ön işlem ve kelime eşleme
        mp = self.meaning(prompt)
        # Skorla tüm veriyi gez
        scored = []
        best = ("I don't get it.", 0.0)
        for text in self.data:
            val = self.same_think(mp, text)
            if val > best[1]:
                best = (text, val)
            if val > 0:
                scored.append((text, val))

        # Eğer hiç skor yoksa fallback: en benzer tekil kelime temelli eşleşme
        if not scored:
            # basit difflib araması verideki en yakın cümleyi getirir
            candidates = self.data if self.data else ["I don't get it."]
            try:
                pick = difflib.get_close_matches(mp, candidates, n=1, cutoff=0.3)
                chosen = pick[0] if pick else best[0]
            except Exception:
                chosen = best[0]
        else:
            # scored içinden seçim: sıcaklığa göre davranış
            scored.sort(key=lambda x: x[1], reverse=True)
            # temperature: 0.0 -> deterministik (en iyi), 1.0 -> rastgele (düşük eşleşmelere izin ver)
            if temperature <= 0.0:
                chosen = scored[0][0]
            else:
                # seçim havuzu büyüklüğü sıcaklığa bağlı
                pool_size = max(1, int(len(scored) * (0.35 + 0.65 * temperature)))
                pool = scored[:pool_size]
                # olasılıkları skora göre normalize et (skoru^p ile keskinleştir)
                weights = [max(s, 1e-6) ** (1.0 if temperature >= 0.6 else 3.0) for (_, s) in pool]
                # normalize
                ssum = sum(weights)
                probs = [w / ssum for w in weights]
                chosen = random.choices([t for (t, _) in pool], weights=probs, k=1)[0]

        # Eğit (isteğe bağlı)
        if trainbot:
            try:
                self.train(prompt)
            except Exception:
                pass

        # Konuşma geçmişine ekle (hem prompt hem response ile)
        self.conversation_history.append({"prompt": prompt, "response": chosen})
        return chosen

# ---------- Başlangıç / Flask API kısmı ----------
chatbot = OmurcekAI()
chatbot.load("CHATBOT_DATA.json")   # dosya ismi sabit, HTML ile uyumlu

@app.route("/chatbot")
def chatbot_page():
    # HTML'i değiştirmedim (orijinal UI olduğu gibi duruyor)
    return """<!DOCTYPE html>
<html lang=\"en\">
<head>
  <meta charset=\"UTF-8\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
  <title>OmurcekAI - ChatBot</title>
  <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-RD06WE730X"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-RD06WE730X');
</script>
  <link href=\"https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap\" rel=\"stylesheet\">
  <style>
    html, body {height:100%; margin:0; padding:0;}
    body {font-family:'Roboto',sans-serif;background:#000;color:#FFD700;display:flex;justify-content:center;align-items:center;}

    .container{width:100%;height:100%;max-width:1920px;max-height:1080px;display:flex;flex-direction:column;justify-content:flex-start;align-items:center;border-radius:12px;box-shadow:0 0 30px rgba(255,215,0,.08);background:linear-gradient(180deg,#050505 0%, #0b0b0b 100%);padding:28px;box-sizing:border-box;}

    .header-row{width:100%;display:flex;flex-direction:column;align-items:center;gap:6px;margin-bottom:6px}
    h1{margin:6px 0 0;color:#FFD700;text-shadow:0 0 10px rgba(255,215,0,.15);font-size:28px}

    /* Small centered warning */
    .warning{max-width:980px;width:94%;text-align:center;font-size:0.92rem;color:#ffb3b3;background:rgba(255,85,85,0.03);padding:8px 12px;border-radius:8px;border:1px solid rgba(255,85,85,0.08);box-shadow:inset 0 1px 0 rgba(255,85,85,0.02);}

    .description{margin-top:6px;text-align:center;font-size:.92rem;padding:6px;color:#FFD700;opacity:.95}

    .messages{flex-grow:1;width:100%;background:#0d0d0d;border:1px solid rgba(255,215,0,0.06);overflow-y:auto;padding:12px;margin:18px 0;border-radius:10px;box-shadow:inset 0 0 20px rgba(255,215,0,.02);min-height:220px}

    .message-user{text-align:right;background:linear-gradient(135deg,#FFD700,#FFB700);color:#000;padding:8px 12px;margin:8px 0;border-radius:15px 15px 0 15px;max-width:70%;margin-left:auto;word-wrap:break-word;box-shadow:0 0 12px rgba(255,215,0,.15);}
    .message-bot{text-align:left;background:rgba(255,215,0,.06);color:#FFD700;padding:8px 12px;margin:8px 0;border-radius:15px 15px 15px 0;max-width:70%;margin-right:auto;word-wrap:break-word;box-shadow:0 0 8px rgba(255,215,0,.08);}

    .input-container{display:flex;justify-content:space-between;width:100%;gap:12px;margin-bottom:8px}
    .input-field{flex-grow:1;padding:12px;border:1px solid rgba(255,215,0,.12);border-radius:8px;background:transparent;color:#FFD700;transition:box-shadow .25s, background .25s;font-size:15px}
    .input-field:focus{outline:none;box-shadow:0 0 28px rgba(255,215,0,.18);background:#0b0b0b}
    .input-field.typing{box-shadow:0 0 28px rgba(255,215,0,.28);}

    .send-button{width:110px;padding:10px 12px;background:#FFD700;border:none;border-radius:8px;cursor:pointer;color:#000;font-weight:700;transition:transform .14s,box-shadow .18s;font-size:15px}
    .send-button:hover{transform:translateY(-2px);box-shadow:0 6px 30px rgba(255,215,0,.18)}
    .send-button:active{animation:glowPulse .9s ease}

    .settings{width:100%;margin-top:12px;border-top:1px dashed rgba(255,215,0,.06);padding-top:14px;display:flex;flex-direction:column;align-items:center;gap:10px}
    .settings-header{color:#FFD700;font-weight:600;margin-bottom:0}

    /* Train row: label & toggle close together */
    .train-row{display:flex;align-items:center;gap:12px;justify-content:center}
    .train-row .train-label{color:#FFD700;font-size:15px;margin:0}

    .toggle-switch{position:relative;display:inline-block;width:60px;height:34px}
    .toggle-switch input{opacity:0;width:0;height:0}
    .slider{position:absolute;cursor:pointer;top:0;left:0;right:0;bottom:0;background:#222;border:1px solid rgba(255,215,0,.12);transition:.35s;border-radius:34px}
    .slider:before{position:absolute;content:"";height:26px;width:26px;left:4px;bottom:3px;background:#FFD700;transition:.35s;border-radius:50%;box-shadow:0 6px 18px rgba(255,215,0,.10)}
    .toggle-switch input:checked + .slider{background:#FFD700;box-shadow:0 0 28px rgba(255,215,0,.16)}
    .toggle-switch input:checked + .slider:before{transform:translateX(26px);background:#000;box-shadow:0 10px 30px rgba(255,215,0,.18);animation:glowPulse 1.4s infinite alternate}

    /* Temperature select - pill style */
    .temp-row{display:flex;align-items:center;gap:12px;justify-content:center}
    select{appearance:none;-webkit-appearance:none;-moz-appearance:none;padding:10px 14px;border-radius:999px;border:1px solid rgba(255,215,0,.12);background:linear-gradient(180deg,#0b0b0b,#0d0d0d);color:#FFD700;cursor:pointer;font-weight:600}
    .select-wrap{position:relative}
    .select-wrap:after{content:"▾";position:absolute;right:12px;top:9px;color:#FFD700;pointer-events:none}
    select:hover{box-shadow:0 8px 26px rgba(255,215,0,.06)}
    select:focus{outline:none;box-shadow:0 0 30px rgba(255,215,0,.12)}

    @keyframes glowPulse{from{box-shadow:0 0 8px rgba(255,215,0,.12)}to{box-shadow:0 0 28px rgba(255,215,0,.28)}}

    /* Modal (warning popup) */
    .modal-overlay{position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.7);z-index:1200}
    .modal{width:min(720px,92%);background:linear-gradient(180deg,#060606,#0b0b0b);border:1px solid rgba(255,215,0,.12);padding:22px;border-radius:12px;text-align:center;color:#FFD700;box-shadow:0 10px 50px rgba(0,0,0,.6)}
    .modal h3{margin:0 0 8px;color:#fff}
    .modal p{color:#ffd6d6;margin:0 0 14px}
    .modal .btn{display:inline-block;padding:10px 16px;border-radius:10px;background:#FFD700;color:#000;border:none;cursor:pointer;font-weight:700;box-shadow:0 8px 30px rgba(255,215,0,.12)}
    .modal .controls{margin-top:8px;display:flex;gap:12px;align-items:center;justify-content:center}
    .modal label{color:#ffd6d6;font-size:14px}

    /* Responsive tweaks for tall screens */
    @media (max-width:900px){
      .container{padding:16px}
      .messages{min-height:300px}
    }
  </style>
</head>
<body>
  <div class=\"container\">
    <div class=\"header-row\">
      <h1>OmurcekAI - ChatBot ⚡</h1>
      <div class=\"warning\">⚠ This is an AI — we can't control what it learns or says. Responsibility is not ours.</div>
      <div class=\"description\">Train, chat & vibe with this AI. Use <b>fetch [URL]</b>!</div>
    </div>

    <div id=\"messages\" class=\"messages\"></div>

    <div class=\"input-container\">
      <input type=\"text\" id=\"userInput\" placeholder=\"Type your message...\" class=\"input-field\" autocomplete=\"off\">
      <button id=\"sendButton\" class=\"send-button\">Send</button>
    </div>

    <div class=\"settings\">
      <div class=\"settings-header\">⚙ Chat Settings</div>

      <div class=\"train-row\">
        <div class=\"train-label\">Train the bot with my messages:</div>
        <label class=\"toggle-switch\"><input type=\"checkbox\" id=\"trainToggle\" checked><span class=\"slider\"></span></label>
      </div>

      <div class=\"temp-row\">
        <div class=\"select-wrap\"><select id=\"temperatureSelect\"><option value=\"0.0\">0.0 (Precise)</option><option value=\"0.4\" selected>0.4 (Default)</option><option value=\"0.7\">0.7 (Creative)</option><option value=\"1.0\">1.0 (Wild)</option></select></div>
      </div>
    </div>
  </div>

  <!-- Modal warning popup -->
  <div id=\"modalOverlay\" class=\"modal-overlay\">
    <div class=\"modal\">
      <h3>Important — Read before using</h3>
      <p>This is an AI. We cannot control what it learns or says. We are not responsible for outputs generated by this bot.</p>
      <div class=\"controls\">
        <label><input type=\"checkbox\" id=\"dontShow\"> Don't show again</label>
      </div>
      <div style=\"margin-top:14px\"><button id=\"understandBtn\" class=\"btn\">I understand</button></div>
    </div>
  </div>

  <script>
    // Show modal unless user opted out
    const modal = document.getElementById('modalOverlay');
    const dontShow = localStorage.getItem('hideAiWarning');
    if (!dontShow) {
      modal.style.display = 'flex';
    }
    document.getElementById('understandBtn').addEventListener('click', ()=>{
      if(document.getElementById('dontShow').checked){
        localStorage.setItem('hideAiWarning', '1');
      }
      modal.style.display='none';
    });

    // Chat send handler
    document.getElementById('sendButton').addEventListener('click', function(){
      const userInput = document.getElementById('userInput');
      const message = userInput.value;
      if (message.trim() === '') return;
      const messagesDiv = document.getElementById('messages');
      messagesDiv.innerHTML += `<div class=\\"message-user\\">${message}</div>`;
      messagesDiv.scrollTop = messagesDiv.scrollHeight;
      userInput.value = '';

      const train = document.getElementById('trainToggle').checked;
      const temperature = document.getElementById('temperatureSelect').value;

      fetch('/chatbot/api/free/use', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: message, train: train, temperature: parseFloat(temperature) })
      })
      .then(r => r.text())
      .then(d => {
        messagesDiv.innerHTML += `<div class=\\"message-bot\\">${d}</div>`;
        messagesDiv.scrollTop = messagesDiv.scrollHeight;
      })
      .catch(e => {
        messagesDiv.innerHTML += `<div class=\\"message-bot\\" style=\\"color:red;\\">Error: ${e.message}</div>`;
        messagesDiv.scrollTop = messagesDiv.scrollHeight;
      });

      // small send animation
      const btn = document.getElementById('sendButton');
      btn.classList.add('active');
      setTimeout(()=>btn.classList.remove('active'), 800);
    });

    // Typing glow effect
    let typingTimer;
    const input = document.getElementById('userInput');
    input.addEventListener('input', ()=>{
      input.classList.add('typing');
      clearTimeout(typingTimer);
      typingTimer = setTimeout(()=>{ input.classList.remove('typing'); }, 800);
    });

    // Allow Enter key to send
    input.addEventListener('keydown', (e)=>{
      if(e.key === 'Enter'){
        e.preventDefault();
        document.getElementById('sendButton').click();
      }
    });
  </script>
</body>
</html>"""

@app.route("/chatbot/api/free/use", methods=["POST"])
def chatbot_free_use():
    global chatbot
    try:
        data = request.get_json()
        text_input = data.get("text", "")
        train_bot_flag = data.get("train", True)
        temp_value = data.get("temperature", 0.4)
        result = chatbot.talk(text_input, trainbot=bool(train_bot_flag), temperature=float(temp_value))
        if train_bot_flag:
            # Kaydetme hatalara karşı try/except içinde
            try:
                chatbot.save("CHATBOT_DATA.json")
            except Exception as e:
                print("Save error:", e)
        return result
    except Exception as e:
        print(f"API Error: {e}")
        return "Internal error. Try again later."

if __name__ == "__main__":
    app.run(debug=True)
